﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrumTable
{
    public class VeriTabanı
    {
         
        public static bool StoryGiris(Story str) 
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            if (Connect.State == ConnectionState.Closed)
            {
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("INSERT INTO Story(Story_Description,StoryLocationX,StoryLocationY,Story_Color,Story_Name,Story_AddDate,Story_Author) VALUES ('" + str.Story_Aciklamasi + "','" + str.StoryKonumuX + "','" + str.StoryKonumuY + "','" + str.Story_Rengi + "','" + str.Story_Adı + "','" + str.Story_Tarih + "','" + str.Story_Yazarı + "')", Connect);
                try
                {
                    Cmd.ExecuteNonQuery();  //Insert, update, delete işlemlerinde kullanılmaktadır. İşlem sonucuna göre geriye int tipinde değer döndürmektedir. 
                }
                catch (SqlException)
                {
                    throw;
                }
                Connect.Close();
                return true;
            }
            else
                return false;
        }

        public static bool TaskGiris(Task tsk) 
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            if (Connect.State == ConnectionState.Closed)
            {
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("INSERT INTO Task(Task_DeadLine,TaskLocationX,TaskLocationY,Task_Author,Task_Status,Task_Description,Story_ID,Task_Color,Task_Header) VALUES('" + tsk.Task_Tarih + "','" + tsk.TaskKonumuX + "','" + tsk.TaskKonumuY + "','" + tsk.TaskYazarı + "','" + tsk.Task_Durumu + "','" + tsk.Task_Aciklamasi + "','" + tsk.Story_ID + "','" + tsk.Task_ArkaPlanRengi + "','" + tsk.Task_Baslik+ "')", Connect);
                try
                {
                    Cmd.ExecuteNonQuery(); //Insert, update, delete işlemlerinde kullanılmaktadır. İşlem sonucuna göre geriye int tipinde değer döndürmektedir. 
                }
                catch (SqlException)
                {
                    return false;
                }
                Connect.Close();
                return true;
            }
            else
                return false;
        }

        public static void TaskDegeriDegistir(int Story_ID)
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            if (Connect.State == ConnectionState.Closed)
            {
                int Task_Deger = 0;
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("SELECT *FROM Story WHERE Story_ID='" + Story_ID + "'", Connect);
                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    if ((int)reader["Story_ID"] == Story_ID)
                    {
                        Task_Deger = (int)reader["Story_Task_Count"];
                        Cmd = new SqlCommand("UPDATE Story SET Story_Task_Count='" + (Task_Deger + 1) + "' WHERE Story_ID='" + Story_ID + "'", Connect);
                    }
                }
                reader.Close();
                Cmd.ExecuteNonQuery();
                Connect.Close();
            }
        }
        public static List<PictureBoxInfo> Select() //Parametre almaz eğer return value Null değerine eşit değil İse İşlem başarılı denebilir.
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            List<PictureBoxInfo> PassValue = new List<PictureBoxInfo>();
            if (Connect.State == ConnectionState.Closed)
            {
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("SELECT * FROM Story", Connect);

                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    PictureBoxInfo AdPic = new PictureBoxInfo();
                    AdPic.PB_ArkaPlan = (reader["Story_Color"].ToString());
                    AdPic.PB_Boyut = new Size(130, 130);
                    AdPic.PB_Konumu = new Point((int)reader["StoryLocationX"], (int)reader["StoryLocationY"]);
                    AdPic.Story_ID = (int)reader["Story_ID"];
                    AdPic.Story_Task_Count = (int)reader["Story_Task_Count"];
                    AdPic.Story_Aciklamasi = (string)reader["Story_Description"];
                    AdPic.Story_Adı = (string)reader["Story_Name"];
                    AdPic.Story_EklenmeTarihi = (string)reader["Story_AddDate"];
                    AdPic.Story_Yazari = (string)reader["Story_Author"];
                    PassValue.Add(AdPic);
                }
                reader.Close();
                Cmd.ExecuteNonQuery();
                Connect.Close();
                return PassValue;
            }
            else
                return null;
        }



        public static List<PictureBoxInfo> TaskSec() 
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            List<PictureBoxInfo> PassValue = new List<PictureBoxInfo>();
            if (Connect.State == ConnectionState.Closed)
            {
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("SELECT * FROM Task", Connect);

                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    PictureBoxInfo Ekle = new PictureBoxInfo();
                    Ekle.Task_Yazari = (string)reader["Task_Author"];
                    Ekle.PB_ArkaPlan = (reader["Task_Color"]).ToString();
                    Ekle.PB_Boyut = new Size(130, 32);
                    Ekle.Task_Tarihi = (string)reader["Task_DeadLine"];
                    Ekle.Task_Basligi = (string)reader["Task_Header"];
                    Ekle.PB_Konumu = new Point((int)reader["TaskLocationX"], (int)reader["TaskLocationY"]);
                    Ekle.Story_ID = (int)reader["Story_ID"];
                    Ekle.Task_ID = (int)reader["Task_ID"];
                    Ekle.Task_Durumu = (int)reader["Task_Status"];
                    PassValue.Add(Ekle); 
                }
                reader.Close();
                Cmd.ExecuteNonQuery();
                Connect.Close();
                return PassValue;
            }
            else
                return null;
        }
        public static bool UpdateTask(int _Task_ID, int Status_Value)
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            if (Connect.State == ConnectionState.Closed) //bağlantı durumu kapalıysa 
            {
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("UPDATE Task SET Task_Status='" + Status_Value + "'WHERE Task_ID=@Task_ID", Connect);
                Cmd.Parameters.AddWithValue("@Task_ID", _Task_ID);
                Cmd.ExecuteNonQuery();
                Connect.Close();
                return true;
            }
            else
                return false;
        }

        public static Point SonTaskItemiGetir(int Story_No)   // Yeni task Ekleneceği zaman eski konumu bulmak için.
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            if (Connect.State == ConnectionState.Closed)
            {
                Point Deger = Point.Empty;
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("SELECT TOP 1 * FROM Task WHERE Story_ID='" + Story_No + "' ORDER BY Task_ID DESC", Connect);
                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    Deger = new Point((int)reader[2], (int)reader[3] + 28);
                }
                reader.Close();
                Cmd.ExecuteNonQuery();
                Connect.Close();
                return Deger;
            }
            else
                return Point.Empty;
        }
        public static string TaskBilgisiGetir(int Task_ID, int Story_ID) //dropdown ve task bilgisi için..
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            if (Connect.State == ConnectionState.Closed)
            {
                string Task_Bilgi = " ";
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("SELECT *FROM Story LEFT JOIN Task ON Task.Story_ID=Story.Story_ID", Connect);

                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    if ((int)reader["Task_ID"] == Task_ID || (int)reader["Story_ID"] == Story_ID)
                    {
                        Task_Bilgi = " Story Adı : " + (string)reader["Story_Name"] + "/ Task Başlığı : " + (string)reader["Task_Header"] + "/ Story Tanımı : " + (string)reader["Story_Description"] + "/ Task Sahibi : " + reader["Task_Author"] + "/ Durum : /" + reader["Task_Status"] + "/ Task Tanımı : " + reader["Task_Description"] + "/ Bitirme Tarihi : " + reader["Task_DeadLine"] + "/ Story Sahibi : " + reader["Story_Author"] + "/ Story Eklenme Tarihi : " + reader["Story_AddDate"];
                        return Task_Bilgi;
                    }
                }
                reader.Close();
                Cmd.ExecuteNonQuery();
                Connect.Close();
            }
            return null;

        }
        


        public static Point SonItemiGetir() 
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            if (Connect.State == ConnectionState.Closed)
            {
                Point PassValue = Point.Empty;
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("SELECT TOP 1 * FROM Story ORDER BY Story_ID DESC", Connect);
                SqlDataReader reader = Cmd.ExecuteReader();
                while (reader.Read())
                {
                    PassValue = new Point((int)reader[2], (int)reader[3] + 140);

                }
                reader.Close();
                Cmd.ExecuteNonQuery();
                Connect.Close();
                return PassValue;
            }
            else
                return Point.Empty;
        }

        

        

        public static bool VeriTabanıSil()
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            if (Connect.State == ConnectionState.Closed)
            {
                Connect.Open();
                SqlCommand Cmd = new SqlCommand("DELETE FROM Task", Connect);
                Cmd.ExecuteNonQuery();
                Cmd = new SqlCommand("DELETE FROM Story", Connect);
                Cmd.ExecuteNonQuery();
                Connect.Close();
                return true;
            }
            else
                return false;
        }

    }
}
