﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScrumTable
{
    public partial class frmTaskEkle : Form
    {
        public frmTaskEkle()
        {
            InitializeComponent();
            foreach (PictureBoxInfo taskInfo in VeriTabanı.Select())
            {
                cbStorys.Items.Add(taskInfo.Story_Adı);
            }
        }

        private void StoryIdAra(string Story_Name)
        {
            foreach (PictureBoxInfo tm in VeriTabanı.Select())
            {
                if (tm.Story_Adı == cbStorys.Text)
                {
                    ThisStory_ID = tm.Story_ID;
                }
            }
        }
        int Ilk_Kontrol;
        int ThisStory_ID;
        Point StoryKonumu;
        private void btnTaskEkle_Click(object sender, EventArgs e)
        {
            frmMain frm = frmMain.GetInstance;
            Button TaskEkle = new Button();
            Task Task = new Task();
            List<PictureBoxInfo> Data = VeriTabanı.Select();
            StoryIdAra(cbStorys.Text);
            VeriTabanı.TaskDegeriDegistir(ThisStory_ID);
            foreach (PictureBoxInfo Instance in Data)
            {
                if (ThisStory_ID == Instance.Story_ID)
                {
                    Ilk_Kontrol = Instance.Story_Task_Count;
                    StoryKonumu = Instance.PB_Konumu;
                    TaskEkle.BackColor = Color.FromArgb(Convert.ToInt32(Instance.PB_ArkaPlan));
                }
            }
            foreach (Panel Panel in frm.Controls.OfType<Panel>())
            {
                if (Panel.Name == "panel5")
                {
                    foreach (Panel Panels in Panel.Controls.OfType<Panel>())
                    {
                        if (Panels.Name == "pnlNotStarted")
                        {
                            Panels.Refresh();
                            TaskEkle.Location = VeriTabanı.SonTaskItemiGetir(ThisStory_ID); 
                            if (Ilk_Kontrol == 0)
                            {
                                TaskEkle.Location = StoryKonumu;
                            }
                        }
                    }
                }
            }
            Task.Task_ArkaPlanRengi = TaskEkle.BackColor.GetHashCode().ToString();
            Task.TaskKonumuX = TaskEkle.Location.X;
            Task.TaskKonumuY = TaskEkle.Location.Y;
            Task.TaskYazarı = txtAuthor.Text;
            Task.Task_Tarih = dtpDeadLine.Value.ToString();
            Task.Task_Aciklamasi = rtbDescription.Text;
            Task.Task_Durumu = 0;//Not Startz
            Task.Story_ID = ThisStory_ID;
            Task.Task_Baslik = txtTask_Header.Text;
            VeriTabanı.TaskGiris(Task);
            Application.Restart();
           
            this.Close();
        }

        private void frmTaskEkle_Load(object sender, EventArgs e)
        {

        }
    }
}
