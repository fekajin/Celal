﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScrumTable
{
    public partial class frmMain : Form
    {
        private static frmMain Instance;
        public frmMain()
        {
            InitializeComponent();
            
        }
        public static frmMain GetInstance
        {
            get
            {
                if (Instance == null || Instance.IsDisposed)
                {
                    Instance = new frmMain();
                }
                return Instance;
            }
        }


        Button DropDown;
        void panel_DragDrop(object sender, DragEventArgs e)
        {
            ((Button)e.Data.GetData(typeof(Button))).Parent = (Panel)sender;
            if (((Panel)sender) == pnlNotStarted)
            {
                VeriTabanı.UpdateTask((int)(DropDown.Tag), 0);
            }
            else if (((Panel)sender) == pnlInProgress)
            {
                VeriTabanı.UpdateTask((int)(DropDown.Tag), 1);
            }
            else if (((Panel)sender) == pnlDone)
            {
                VeriTabanı.UpdateTask((int)(DropDown.Tag), 2);
            }
        }

        void PicDropDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                DropDown = (sender as Button);
                ((Button)sender).DoDragDrop(((Button)sender), DragDropEffects.Move);
            }
            string[] R;
            if (e.Button == MouseButtons.Right)
            {
                int SenderValue = (int)((Button)sender).Tag;
                R = VeriTabanı.TaskBilgisiGetir(SenderValue, 0).Split('/');
                switch (R[5])
                {
                    case "0":
                        Status = "Başlanmadı(Not Started)";
                        break;
                    case "1":
                        Status = "İşlemde(In Progress)";
                        break;
                    case "2":
                        Status = "Bitirildi!(Done!)";
                        break;
                    default:
                        break;
                }
                MessageBox.Show(this, "" + R[0] + "\n" + R[1] + "\n" + R[3] + "\n Task Durumu : " + Status + "\n" + R[6] + "\n" + R[7], "TASK BİLGİLERİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        void panel_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        public void RefreshEvent()
        {
            ClearPanelEvent();
            List<PictureBoxInfo> Datas = VeriTabanı.Select();
            foreach (PictureBoxInfo PBDatas in Datas)
            {
                Button PictureBox = new Button();
                PictureBox.Margin = new Padding(0);
                PictureBox.Font = new Font("segoe script", 10, FontStyle.Regular);
                PictureBox.Size = PBDatas.PB_Boyut;
                PictureBox.MouseDown += Story_RightClicked;
                PictureBox.BackColor = Color.FromArgb(Int32.Parse(PBDatas.PB_ArkaPlan));
                pnlStory.Controls.Add(PictureBox);
                PictureBox.Location = PBDatas.PB_Konumu;
                PictureBox.Tag = PBDatas.Story_ID;
                PictureBox.Text = "Name:" + PBDatas.Story_Adı + "\nDate:" + PBDatas.Story_EklenmeTarihi + "\nDesc:" + PBDatas.Story_Aciklamasi;
                PictureBox.ForeColor = Color.Black;
            }

            List<PictureBoxInfo> Datam = VeriTabanı.TaskSec();
            foreach (PictureBoxInfo PBData in Datam)
            {
                Button Btn = new Button();
                Btn.Margin = new Padding(0);
                Btn.Font = new Font("segoe script", 10, FontStyle.Regular);
                Btn.Size = PBData.PB_Boyut;
                Btn.BackColor = Color.FromArgb(Int32.Parse(PBData.PB_ArkaPlan));
                Btn.Tag = PBData.Task_ID;
                Btn.DragDrop += panel_DragDrop;
                Btn.MouseDown += PicDropDown;
                Btn.Text = PBData.Task_Basligi;
                Btn.ForeColor = Color.Black;
                switch (PBData.Task_Durumu)
                {
                    case 0:
                        pnlNotStarted.Controls.Add(Btn);

                        break;
                    case 1:
                        pnlInProgress.Controls.Add(Btn);

                        break;
                    case 2:
                        pnlDone.Controls.Add(Btn);

                        break;
                    default:
                        break;
                }
                Btn.Location = PBData.PB_Konumu;
            }
            pnlNotStarted.Size = new Size(pnlNotStarted.Size.Width, panel5.Size.Height);
            pnlInProgress.Size = new Size(pnlNotStarted.Size.Width, panel5.Size.Height);
            pnlDone.Size = new Size(pnlNotStarted.Size.Width, panel5.Size.Height);
        }

        public void ClearPanelEvent()
        {
            pnlStory.Controls.Clear();
            pnlNotStarted.Controls.Clear();
            pnlInProgress.Controls.Clear();
            pnlDone.Controls.Clear();
        }


        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        string Status;

        private void Story_RightClicked(object sender, MouseEventArgs e)
        {
            string[] Veri;
            if (e.Button == MouseButtons.Right)
            {
                int SenderValue = (int)((Button)sender).Tag;
                Veri = VeriTabanı.TaskBilgisiGetir(0, SenderValue).Split('/');
                MessageBox.Show(this, "" + Veri[0] + "\n" + Veri[2] + "\n" + Veri[8] + "\n" + Veri[9] + "\n", "STORY BİLGİLERİ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void btnStoryEkle_Click(object sender, EventArgs e)
        {
            frmStoryEkle frm = new frmStoryEkle();
            frm.Show();
        }

        private void btnTaskEkle_Click(object sender, EventArgs e)
        {
            frmTaskEkle frm = new frmTaskEkle();
            frm.Show();
        }
        
        private void frmMain_Load(object sender, EventArgs e)
        {
            RefreshEvent();

        }


        private void frmMain_Load_1(object sender, EventArgs e)
        {
            RefreshEvent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnBaglanti_Click(object sender, EventArgs e)
        {
            SqlConnection Connect = new SqlConnection("Data Source=ABRA-A5-V4;Initial Catalog=ScrumTableDB;Integrated Security=True");
            MessageBox.Show("Bağlantı Başarılı!");
        }

        private void btnVeriSil_Click_1(object sender, EventArgs e)
        {
            DialogResult Ans = MessageBox.Show(this, "\n\n Veri Tabanını Silmek İstiyor Musunuz??", "DİKKAT!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Ans == DialogResult.Yes)
            {
                VeriTabanı.VeriTabanıSil();
                RefreshEvent();
            }
        }

       
    }
}
